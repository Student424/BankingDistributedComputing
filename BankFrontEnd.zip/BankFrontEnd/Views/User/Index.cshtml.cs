using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BankWebApp.Views.Users
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
