using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BankWebApp.Views.Users
{
    public class ProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
