using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BankWebApp.Views.Home
{
    public class AdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
