﻿// ---- API base (change only this line if your API port/path is different)
const BASE_API = 'https://localhost:7006/api';

/**
 * Safe fetch helper that preserves the HTTP method you pass (GET/PUT/POST/DELETE).
 * It also JSON-encodes the body when needed and returns a structured error object
 * instead of throwing, so your UI can show "Save failed".
 */
async function apiFetch(endpoint, options = {}) {
    // build URL and collapse duplicate slashes (but keep https://)
    const url = `${BASE_API}/${endpoint}`.replace(/([^:]\/)\/+/g, '$1');

    const method = options.method ? options.method.toUpperCase() : 'GET';

    const headers = {
        'Content-Type': 'application/json',
        ...(options.headers || {})
    };

    let body = options.body;
    if (body && typeof body !== 'string') body = JSON.stringify(body);

    const res = await fetch(url, { method, headers, body });

    if (!res.ok) {
        const text = await res.text().catch(() => '');
        return { error: true, status: res.status, message: text || res.statusText };
    }

    // 204 No Content
    if (res.status === 204) return null;

    // try json; if it fails, return raw text
    try { return await res.json(); } catch { return await res.text(); }
}

// ---- Navbar greeting and logout ----
document.addEventListener('DOMContentLoaded', () => {
    const name = localStorage.getItem('userName');
    if (name) {
        const g = document.getElementById('navGreeting');
        if (g) g.textContent = `Hi, ${name}`;
    }

    const logout = document.getElementById('logoutLink');
    if (logout) {
        logout.addEventListener('click', e => {
            e.preventDefault();
            localStorage.clear();
            alert('Logged out.');
            location.href = '/Home/Login';
        });
    }
});