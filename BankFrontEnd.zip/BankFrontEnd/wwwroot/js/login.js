﻿document.addEventListener("DOMContentLoaded", () => {
    const loginBtn = document.getElementById("loginBtn");
    if (!loginBtn) return;

    loginBtn.addEventListener("click", async () => {
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();
        const msg = document.createElement("div");
        msg.className = "mt-2 text-danger";
        document.querySelector(".card").appendChild(msg);
        msg.textContent = "";

        if (!email || !password) {
            msg.textContent = "Please enter both email and password.";
            return;
        }

        const res = await apiFetch("auth/login", {
            method: "POST",
            body: { email, password }
        });

        if (res.error) {
            msg.textContent = res.message || "Login failed.";
            return;
        }

        const role = res.Role || res.role || "";
        localStorage.setItem("userId", res.Id || res.id || res.userId || res.UserId);
        localStorage.setItem("userEmail", res.Email || res.email || res.UserEmail);
        localStorage.setItem("userRole", res.Role || res.role || res.UserRole);

        if (role.toLowerCase() === "admin") {
            window.location.href = "/Admin/Dashboard";
        } else {
            window.location.href = "/User/Dashboard";
        }


    });
});
