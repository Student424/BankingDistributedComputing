﻿// ===== simple globals =====
const CURRENT_USER_ID = localStorage.getItem('userId');
          // demo user
const USER_PATH = 'User';             // change to 'users' if your backend uses /api/users/{id}
let _userCache = null;

// Redirect to login for protected pages like admin n user
const path = window.location.pathname.toLowerCase();
const isLoginPage = path.includes("/home/login") || path === "/" || path.includes("/home/index");

if (!CURRENT_USER_ID && !isLoginPage) {
    alert("Please log in first.");
    window.location.href = "/Home/Login";
}

// keep the loaded user so we can send PasswordHash back

console.log("admin-users.js loaded");

async function loadUsers() {
    console.log("Fetching from:", `${BASE_API}/user`);
    try {
        const res = await fetch(`${BASE_API}/user`);
        console.log("Response status:", res.status);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        console.log("Data:", data);
        // render here...
    } catch (err) {
        console.error("Fetch failed:", err);
    }
}

loadUsers();

document.addEventListener('DOMContentLoaded', () => {
    // Run only on pages that have these elements

    // Dashboard bits
    if (document.getElementById('profileCard')) {
        loadUserProfile().catch(console.error);
    }
    if (document.getElementById('accountsList')) {
        loadAccounts().catch(console.error);
    }
    if (document.getElementById('filterBtn')) {
        document.getElementById('filterBtn').addEventListener('click', applyTxnFilter);
    }

    // Edit profile page
    if (document.getElementById('profileForm')) {
        fillProfileForm().catch(console.error);
        document.getElementById('profileForm').addEventListener('submit', saveProfile);
    }

    // Transactions page (optional)
    if (document.getElementById('txFilterBtn')) {
        document.getElementById('txFilterBtn').addEventListener('click', loadTransactionsForSelected);
    }

    // Transfer form (optional)
    if (document.getElementById('transferForm')) {
        loadAccountsIntoSelect('fromAccount').catch(console.error);
        document.getElementById('transferForm').addEventListener('submit', submitTransfer);
    }
});

// ===== dashboard/profile =====

async function loadUserProfile() {
    const box = document.getElementById('profileCard');
    box && (box.textContent = 'Loading profile...');
    const data = await apiFetch(`${USER_PATH}/${CURRENT_USER_ID}`);
    if (data && !data.error) {
        _userCache = data;
        if (box) {
            box.innerHTML = `
        <div>
          <strong>${data.name ?? ''}</strong>
          <div class="text-small">${data.email ?? ''}</div>
          <div class="text-small">${data.phone ?? ''}</div>
          <div class="text-small">${data.address ?? ''}</div>
        </div>`;
        }
    } else {
        box && (box.textContent = 'Profile could not be loaded');
    }
}

async function fillProfileForm() {
    const data = await apiFetch(`${USER_PATH}/${CURRENT_USER_ID}`);
    if (!data || data.error) return;
    _userCache = data;
    document.getElementById('pfName').value = data.name ?? '';
    document.getElementById('pfEmail').value = data.email ?? '';
    document.getElementById('pfPhone').value = data.phone ?? '';
    document.getElementById('pfAddress').value = data.address ?? '';
}

// Save updated profile info (PUT) – includes PasswordHash to satisfy model validation
async function saveProfile(e) {
    e.preventDefault();

    const userId = CURRENT_USER_ID;
    const payload = {
        id: userId,
        name: document.getElementById('pfName').value,
        email: document.getElementById('pfEmail').value,
        phone: document.getElementById('pfPhone').value,
        address: document.getElementById('pfAddress').value,
        passwordHash: _userCache?.passwordHash || '' // important if model requires it
    };

    const res = await apiFetch(`${USER_PATH}/${CURRENT_USER_ID}`, { method: 'PUT', body: payload });

    const result = document.getElementById('profileResult');
    if (res && res.error) {
        result && (result.textContent = 'Save failed');
    } else {
        result && (result.textContent = 'Saved successfully');
        // refresh dashboard card if present
        if (document.getElementById('profileCard')) loadUserProfile();
    }
}

// ===== accounts & transactions (light versions that won’t break pages) =====

async function loadAccounts() {
    const list = document.getElementById('accountsList');
    const acctSel = document.getElementById('txnAccountSelect'); // optional dropdown
    list && (list.textContent = 'Loading accounts...');
    // if you already have /api/accounts/by-user/{id} use that; otherwise /api/accounts and filter
    let data = await apiFetch(`Accounts/by-user/${CURRENT_USER_ID}`);
    if (data?.error) data = await apiFetch('accounts');

    if (!data || data.error) { list && (list.textContent = 'Error loading accounts'); return; }

    // if endpoint returned all accounts, keep only this user's
    const accounts = Array.isArray(data) ? data.filter(a => a.userProfileId === CURRENT_USER_ID || a.userId === CURRENT_USER_ID) : [];
    list && (list.innerHTML = '');
    acctSel && (acctSel.innerHTML = '');

    accounts.forEach(a => {
        list && list.insertAdjacentHTML(
            'beforeend',
            `<div class="card mb-2 p-2">
        <div><strong>${a.accountNumber}</strong></div>
        <div class="text-small">Balance: ${Number(a.balance).toFixed(2)}</div>
        <div class="mt-1"><button class="btn btn-sm btn-outline-secondary" onclick="loadTransactions(${a.id})">View transactions</button></div>
      </div>`
        );
        acctSel && acctSel.insertAdjacentHTML('beforeend', `<option value="${a.id}">${a.accountNumber}</option>`);
    });

    if (list && accounts.length === 0) list.textContent = 'No accounts';
}

async function loadTransactions(accountId) {
    const out = document.getElementById('transactionsList');
    if (!out) return;
    out.textContent = 'Loading...';
    const txs = await apiFetch(`transactions/history/${accountId}`);
    renderTxnTable(out, txs);
}

async function applyTxnFilter() {
    const accountId = document.getElementById('txnAccountSelect').value;
    const from = document.getElementById('filterFrom').value;
    const to = document.getElementById('filterTo').value;
    const out = document.getElementById('transactionsList');
    if (!accountId || !out) return;

    let txs = await apiFetch(`transactions/history/${accountId}`);
    if (!txs || txs.error) { out.textContent = 'No transactions'; return; }

    // simple date filter
    const f = txs.filter(t => {
        const d = new Date(t.timestampUtc || t.timestampsUtc || t.date);
        if (from && d < new Date(from)) return false;
        if (to) { const td = new Date(to); td.setHours(23, 59, 59); if (d > td) return false; }
        return true;
    });

    renderTxnTable(out, f);
}

function renderTxnTable(container, rows) {
    if (!rows || rows.length === 0) { container.textContent = 'No transactions'; return; }

    const body = rows.map(t => `
    <tr>
      <td>${new Date(t.timestampUtc || t.timestampsUtc || t.date).toLocaleString()}</td>
      <td>${t.accountId ?? ''}</td>
      <td>${typeof t.type === 'number' ? (t.type === 1 ? 'Deposit' : 'Withdraw') : (t.type ?? '')}</td>
      <td>${Number(t.amount).toFixed(2)}</td>
      <td>${t.description ?? ''}</td>
    </tr>
  `).join('');

    const html = `
    <table class="table table-sm">
      <thead><tr><th>Date</th><th>AccId</th><th>Type</th><th>Amount</th><th>Desc</th></tr></thead>
      <tbody>${body}</tbody>
    </table>`;
    container.innerHTML = html;
}

// ===== transfer form (optional; safe no-op if you don’t use it) =====
async function loadAccounts() {
    const list = document.getElementById('accountsList');
    const acctSel = document.getElementById('txnAccountSelect');
    list && (list.textContent = 'Loading accounts...');

    try {
        //  Correct API casing (capital A)
        const data = await apiFetch(`Accounts/by-user/${CURRENT_USER_ID}`);

        console.log("Accounts fetched:", data); // Debug log

        if (!data || data.error || !Array.isArray(data)) {
            list && (list.textContent = 'No accounts found');
            return;
        }

        //  Filter accounts belonging to current user (extra safety)
        const accounts = data.filter(a => a.userProfileId == CURRENT_USER_ID || a.userId == CURRENT_USER_ID);

        if (accounts.length === 0) {
            list && (list.textContent = 'No accounts');
            return;
        }

        //  Render user’s accounts
        list.innerHTML = '';
        acctSel && (acctSel.innerHTML = '');

        accounts.forEach(a => {
            list.insertAdjacentHTML(
                'beforeend',
                `<div class="card mb-2 p-2">
                    <div><strong>${a.accountNumber}</strong> (${a.type})</div>
                    <div class="text-small">Balance: RM ${Number(a.balance).toFixed(2)}</div>
                </div>`
            );
            acctSel && acctSel.insertAdjacentHTML(
                'beforeend',
                `<option value="${a.id}">${a.accountNumber} - ${a.type}</option>`
            );
        });
    } catch (err) {
        console.error("Failed to load accounts:", err);
        list && (list.textContent = 'Error loading accounts');
    }
}

async function submitTransfer(e) {
    e.preventDefault();
    const from = document.getElementById('fromAccount').value;
    const to = document.getElementById('toAccountNumber').value;
    const amt = parseFloat(document.getElementById('transferAmount').value);
    const out = document.getElementById('transferResult');
    if (!from || !to || !(amt > 0)) { out && (out.textContent = 'Please enter valid transfer details'); return; }

    // try a backend /transactions/transfer endpoint if you have one
    let res = await apiFetch(`Transactions/transfer`, { method: 'POST', body: { fromAccount: from, toAccount: to, amount: amt } });
    if (res && !res.error) { out && (out.textContent = 'Transfer request sent.'); return; }

    // fallback: withdraw then deposit (non-atomic, dev/demo only)
    const src = await apiFetch(`accounts/by-number/${from}`);
    if (!src || src.error) { out && (out.textContent = 'Source account not found'); return; }
    if (Number(src.balance) < amt) { out && (out.textContent = 'Insufficient funds'); return; }
    const w = await apiFetch(`transactions/${src.id}/withdraw`, { method: 'POST', body: { amount: amt } });
    if (w && w.error) { out && (out.textContent = 'Withdraw failed'); return; }
    const dst = await apiFetch(`accounts/by-number/${to}`);
    if (!dst || dst.error) { out && (out.textContent = 'Destination account not found'); return; }
    const d = await apiFetch(`transactions/${dst.id}/deposit`, { method: 'POST', body: { amount: amt } });
    if (d && d.error) { out && (out.textContent = 'Deposit failed'); return; }
    out && (out.textContent = 'Transfer completed.');
    loadAccounts().catch(() => { });
}

// transfer form helper
async function loadAccountsIntoSelect(selectId) {
    const sel = document.getElementById(selectId);
    if (!sel) return;

    try {
        // ✅ Correct endpoint casing (capital A)
        let data = await apiFetch(`Accounts/by-user/${CURRENT_USER_ID}`);

        // fallback if that endpoint fails
        if (data?.error) data = await apiFetch('Accounts');

        if (!data || data.error) {
            console.warn("No accounts data available:", data);
            return;
        }

        // ✅ Filter for the current user's accounts
        const mine = data.filter(a => a.userProfileId == CURRENT_USER_ID || a.userId == CURRENT_USER_ID);

        // ✅ Populate dropdown
        sel.innerHTML = '';
        if (mine.length === 0) {
            sel.insertAdjacentHTML('beforeend', `<option>No accounts available</option>`);
            return;
        }

        mine.forEach(a => {
            sel.insertAdjacentHTML(
                'beforeend',
                `<option value="${a.accountNumber}">
                    ${a.accountNumber} (${a.type}) - RM ${Number(a.balance).toFixed(2)}
                </option>`
            );
        });

        console.log("Accounts loaded into dropdown:", mine);

    } catch (err) {
        console.error("Failed to load accounts into select:", err);
    }
}

