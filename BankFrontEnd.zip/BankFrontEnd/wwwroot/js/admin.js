﻿// admin.js


// Wait until everything on the page is loaded before running any of this
document.addEventListener('DOMContentLoaded', () => {
    // Only run these functions if their elements exist on the current page
    if (document.getElementById('adminUsersList')) loadAdminUsers();
    if (document.getElementById('adminTxList')) loadAdminTransactions();

    // Set up button clicks for creating new users and filtering transactions
    if (document.getElementById('adminNewUserBtn')) document.getElementById('adminNewUserBtn').addEventListener('click', newUserPrompt);
    if (document.getElementById('adminTxFilterBtn')) document.getElementById('adminTxFilterBtn').addEventListener('click', loadAdminTransactions);
});

// Load all users from the server and show them in the admin panel
async function loadAdminUsers() {
    const data = await apiFetch('user');
    const list = document.getElementById('adminUsersList');
    list.innerHTML = '';

    // If something went wrong or no data came back
    if (!data || data.error) { list.innerText = 'No users'; return; }

    // Loop through each user and display their info with Edit/Delete buttons
    data.forEach(u => {
        list.insertAdjacentHTML('beforeend', `<div class="card mb-1 p-2"><div><strong>${u.name}</strong> (${u.email})</div><div class="mt-1"><button class="btn btn-sm btn-outline-primary" onclick="editUser(${u.id})">Edit</button> <button class="btn btn-sm btn-outline-danger" onclick="deleteUser(${u.id})">Delete</button></div></div>`);
    });
}

// Let admin edit a user’s name and update it in the database
async function editUser(id) {
    const u = await apiFetch(`user/${id}`);
    const newName = prompt('Full name', u.name);
    if (!newName) return;
    const payload = { ...u, name: newName };
    const res = await apiFetch(`user/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
    if (!res || res.error) alert('Update failed'); else loadAdminUsers();// reload list to show changes
}

// Delete a user after confirming with admin
async function deleteUser(id) {
    if (!confirm("Are you sure you want to delete this user?")) return;

    try {
        const res = await fetch(`${BASE_API}/user/${id}`, { method: "DELETE" });

        if (res.ok) {
            alert(" User deleted successfully!");
            location.reload();
        } else {
            const msg = await res.text();
            console.error("Delete failed:", msg);
            alert(" Delete failed on server.");
        }
    } catch (err) {
        console.error("Network error deleting user:", err);
        alert(" Delete failed (network error).");
    }
}


// Create a new user using simple input prompts
function newUserPrompt() {
    const name = prompt('Name');
    const email = prompt('Email');
    if (!name || !email) return;
    const payload = { name: name, email: email, phone: '', address: '', passwordHash: '' };
    apiFetch('user', { method: 'POST', body: JSON.stringify(payload) }).then(res => {
        if (!res || res.error) alert('Create failed'); else loadAdminUsers();
    });
}

// Load and optionally filter transactions by date range
async function loadAdminTransactions() {
    const from = document.getElementById('adminTxFrom').value;
    const to = document.getElementById('adminTxTo').value;

    // Fetch all transactions first
    const txs = await apiFetch('transactions');
    const out = document.getElementById('adminTxList');
    out.innerHTML = '';
    if (!txs || txs.error) { out.innerText = 'No transactions'; return; }

    // Filter transactions between the selected dates
    let filtered = txs;
    if (from) { const fd = new Date(from); filtered = filtered.filter(t => new Date(t.date) >= fd); }
    if (to) { const td = new Date(to); td.setHours(23, 59, 59); filtered = filtered.filter(t => new Date(t.date) <= td); }

    // Build and show a simple table with transaction details
    let html = '<table class="table table-sm"><thead><tr><th>Date</th><th>AccId</th><th>Type</th><th>Amount</th><th>Desc</th></tr></thead><tbody>';
    filtered.forEach(t =>
        html += `
        <tr>
        <td>${new Date(t.date).toLocaleString()}</td>
        <td>${t.accountId}</td>
        <td>${t.type}</td>
        <td>${parseFloat(t.amount).toFixed(2)}</td>
        <td>${t.description || ''}</td
        ></tr>`);
    html += '</tbody></table>';
    out.innerHTML = html;

    document.addEventListener('DOMContentLoaded', () => {
        const usersHost = document.getElementById('usersHost');
        if (usersHost) {
            loadUsers();
            wireNewUserForm();
        }
    });

    async function loadUsers() {
        const host = document.getElementById('usersHost');
        host.innerHTML = 'Loading...';
        const users = await apiFetch('user');      // GET /api/user  (list)
        if (!users || users.error) { host.innerHTML = 'Failed to load.'; return; }

        if (users.length === 0) {
            host.innerHTML = '<div class="text-muted">No users yet.</div>';
            return;
        }

        const rows = users.map(u => `
    <tr>
      <td>${u.id}</td>
      <td>${u.name ?? ''}</td>
      <td>${u.email ?? ''}</td>
      <td>${u.phone ?? ''}</td>
      <td>${u.address ?? ''}</td>
      <td>
        <button class="btn btn-sm btn-outline-danger" onclick="adminDeleteUser(${u.id})">Delete</button>
      </td>
    </tr>
  `).join('');

        host.innerHTML = `
    <table class="table table-sm">
      <thead><tr><th>Id</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th></th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
    }

    async function adminDeleteUser(id) {
        if (!confirm('Delete this user?')) return;
        const res = await apiFetch(`user/${id}`, { method: 'DELETE' }); // DELETE /api/user/{id}
        if (res === null || (res && !res.error)) {
            result && (result.textContent = 'Saved successfully');
        } else {
            result && (result.textContent = 'Save failed');
        }

        loadUsers();
    }

    function wireNewUserForm() {
        const btn = document.getElementById('btnNewUser');
        const form = document.getElementById('newUserForm');
        const msg = document.getElementById('nuMsg');

        if (!btn || !form) return;

        btn.addEventListener('click', () => { form.style.display = ''; msg.textContent = ''; });

        document.getElementById('nuCancel').addEventListener('click', () => {
            form.style.display = 'none';
        });

        document.getElementById('nuSave').addEventListener('click', async () => {
            msg.textContent = '';
            const payload = {
                name: document.getElementById('nuName').value,
                email: document.getElementById('nuEmail').value,
                phone: document.getElementById('nuPhone').value,
                address: document.getElementById('nuAddress').value,
                passwordHash: 'TEMP' // if your model requires it; otherwise remove
            };

            const res = await apiFetch('user', { method: 'POST', body: payload }); // POST /api/user
            if (res && res.error) { msg.textContent = 'Save failed'; return; }
            form.style.display = 'none';
            loadUsers();
        });
    }
}
