﻿using System;

namespace BankWebApp.Models
{
    public class Transaction
    {
        public int Id { get; set; }
        public int AccountId { get; set; }
        public decimal Amount { get; set; }
        public string Type { get; set; } = ""; // deposit, withdraw, transfer
        public DateTime Date { get; set; }
        public string? Description { get; set; }
    }
}
