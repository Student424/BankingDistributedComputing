﻿namespace BankWebApp.Models
{
    public class Account
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; } = "";
        public decimal Balance { get; set; }
        public int UserProfileId { get; set; }
        public string AccountType { get; set; } = "Checking";
    }
}
