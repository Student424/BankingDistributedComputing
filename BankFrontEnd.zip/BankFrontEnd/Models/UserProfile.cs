﻿using System;

namespace BankWebApp.Models
{
    public class UserProfile
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Email { get; set; } = "";
        public string Address { get; set; } = "";
        public string Phone { get; set; } = "";
        public string? Picture { get; set; }
        public string PasswordHash { get; set; } = "";
    }
}
