using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

// Create a WebApplication builder (entry point for configuring services and middleware)
var builder = WebApplication.CreateBuilder(args);

// Register MVC services - enables Controllers and Razor Views
builder.Services.AddControllersWithViews();

// (Optional) Enable CORS - allows requests from external origins (useful for fetch() or API calls)
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy
            .AllowAnyOrigin()   // Allow requests from any domain (safe for dev; restrict in production)
            .AllowAnyHeader()   // Allow all HTTP headers
            .AllowAnyMethod()); // Allow all HTTP methods (GET, POST, PUT, DELETE, etc.)
});

builder.Services.AddHttpClient("Backend", c =>
    c.BaseAddress = new Uri(builder.Configuration["Api:BaseUrl"]!)); 


// Build the app (finalize configuration)
var app = builder.Build();

// Configure the error handling middleware for production
if (!app.Environment.IsDevelopment())
{
    // Redirects to a custom error page if an unhandled exception occurs
    app.UseExceptionHandler("/Home/Error");
}

// Serve static files (CSS, JS, images) from the wwwroot folder
app.UseStaticFiles();

// Enable routing - allows ASP.NET Core to map URLs to controllers and actions
app.UseRouting();

// Enable the CORS policy configured earlier
app.UseCors();

// Configure default route for MVC controllers
// Example: /Home/Index -> calls HomeController.Index()
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Run the application - starts listening for incoming HTTP requests
app.Run();
