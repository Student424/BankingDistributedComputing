﻿using Microsoft.AspNetCore.Mvc;

namespace BankWebApp.Controllers
{
    public class UserController : Controller
    {
        // returns the main user dashboard view
        public IActionResult Dashboard() => View();

        // profile edit view
        public IActionResult Profile() => View();

        // transactions view
        public IActionResult Transactions() => View();

        // transfer view
        public IActionResult Transfer() => View();
    }
}
