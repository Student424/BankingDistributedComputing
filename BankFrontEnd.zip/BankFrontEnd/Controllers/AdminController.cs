﻿using Microsoft.AspNetCore.Mvc;

namespace BankWebApp.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Dashboard() => View();
        public IActionResult Users() => View();
        public IActionResult Transactions() => View();
        public IActionResult Logs() => View();
    }
}
