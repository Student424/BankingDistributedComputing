using Microsoft.AspNetCore.Mvc;

namespace BankWebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
        public IActionResult Login() => View();
        public IActionResult Admin() => View();
        public IActionResult Error() => View();
    }
}
