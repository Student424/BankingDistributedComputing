﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Bank_Data_Web_Service.Models;

namespace Bank_Data_Web_Service.Data
{
    public static class SeedData
    {
        // Call await SeedData.EnsureSeededAsync(db);
        public static async Task EnsureSeededAsync(BankDbContext db)
        {
            //  compute SHA256 must match AuthController hashing
            static string HashSha256(string plain)
            {
                using var sha = SHA256.Create();
                var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(plain ?? ""));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }

            // demo passwords 
            const string demoPassword = "12345";

            //for generating demo user
            //seed only if base users missing
            if (!db.Users.Any(u => u.Email == "admin@mail.com"))
            {
                
                // Create users
                var admin = new UserProfile
                {
                    Name = "Admin User",
                    Email = "admin@mail.com",
                    PasswordHash = HashSha256(demoPassword),
                    Role = "Admin",
                    Address = "Bank HQ",
                    Phone = "0123456789"
                };

                var user1 = new UserProfile
                {
                    Name = "Nana",
                    Email = "user1@mail.com",
                    PasswordHash = HashSha256(demoPassword),
                    Role = "User",
                    Address = "Lot 3662, Lorong Merbau",
                    Phone = "0111234567"
                };

                var user2 = new UserProfile
                {
                    Name = "Lily",
                    Email = "user2@mail.com",
                    PasswordHash = HashSha256(demoPassword),
                    Role = "User",
                    Address = "Jalan Bunga Raya",
                    Phone = "0197654321"
                };

                // Add the users into data
                db.Users.AddRange(admin, user1, user2);
                await db.SaveChangesAsync();

                // Create accounts 
                db.Accounts.AddRange(
                    new Account { UserProfileId = user1.Id, AccountNumber = "10001", Balance = 4800.50M, Type = "Savings" },
                    new Account { UserProfileId = user1.Id, AccountNumber = "10002", Balance = 2500.00M, Type = "Current" },

                    new Account { UserProfileId = user2.Id, AccountNumber = "20001", Balance = 9500.00M, Type = "Savings" },
                    new Account { UserProfileId = user2.Id, AccountNumber = "20002", Balance = 1200.00M, Type = "Current" }
                );
                await db.SaveChangesAsync();

                // Example transactions (for demo)
                // Use existing account Ids 
                var acc10001 = db.Accounts.FirstOrDefault(a => a.AccountNumber == "10001");
                var acc20001 = db.Accounts.FirstOrDefault(a => a.AccountNumber == "20001");

                if (acc10001 != null)
                {
                    db.Transactions.Add(new Transaction
                    {
                        AccountId = acc10001.Id,
                        Type = TransactionType.Deposit,
                        Amount = 1000M,
                        BalanceAfter = acc10001.Balance,
                        Description = "Initial deposit",
                        TimestampsUtc = DateTime.UtcNow.AddDays(-7)
                    });
                }

                if (acc20001 != null)
                {
                    db.Transactions.Add(new Transaction
                    {
                        AccountId = acc20001.Id,
                        Type = TransactionType.Deposit,
                        Amount = 500M,
                        BalanceAfter = acc20001.Balance,
                        Description = "Salary",
                        TimestampsUtc = DateTime.UtcNow.AddDays(-3)
                    });
                }

                await db.SaveChangesAsync();
            }

            int existingUserCount = db.Users.Count();
            int targetTotalUsers = 20; // adjust if you want more
            int usersToGenerate = targetTotalUsers - existingUserCount;


            if (usersToGenerate > 0)
            {
                Console.WriteLine($"Generating {usersToGenerate} background demo users...");
                var random = new Random();

                for (int i = 0; i < usersToGenerate; i++)
                {
                    string randomName = $"User_{random.Next(1000, 9999)}";
                    string randomEmail = $"{randomName.ToLower()}@mail.com";
                    string randomHash = HashSha256(demoPassword);

                    var newUser = new UserProfile
                    {
                        Name = randomName,
                        Email = randomEmail,
                        PasswordHash = randomHash,
                        Role = "User",
                        Address = $"No. {random.Next(1, 500)} Jalan Data City",
                        Phone = $"01{random.Next(10000000, 99999999)}"
                    };

                    db.Users.Add(newUser);
                    await db.SaveChangesAsync(); // save first to get UserProfileId

                    // generate 1–3 accounts per user
                    int accountCount = random.Next(1, 4);
                    for (int a = 0; a < accountCount; a++)
                    {
                        var account = new Account
                        {
                            UserProfileId = newUser.Id,
                            AccountNumber = random.Next(30000, 99999).ToString(),
                            Balance = (decimal)(random.NextDouble() * 9000 + 1000),
                            Type = random.Next(0, 2) == 0 ? "Savings" : "Current"
                        };
                        db.Accounts.Add(account);
                        await db.SaveChangesAsync(); // flush to get AccountId

                        // generate 3–5 random transactions per account
                        int txCount = random.Next(3, 6);
                        for (int t = 0; t < txCount; t++)
                        {
                            db.Transactions.Add(new Transaction
                            {
                                AccountId = account.Id,
                                Type = random.Next(0, 2) == 0 ? TransactionType.Deposit : TransactionType.Withdrawal,
                                Amount = (decimal)(random.NextDouble() * 700 + 100),
                                Description = random.Next(0, 2) == 0 ? "Online Transfer" : "ATM Withdrawal",
                                BalanceAfter = account.Balance,
                                TimestampsUtc = DateTime.UtcNow.AddDays(-random.Next(1, 60))
                            });
                        }
                        await db.SaveChangesAsync();
                    }
                }

                Console.WriteLine($"✅ Generated {usersToGenerate} background demo users successfully!");
            }
            else
            {
                Console.WriteLine("✅ Background users already exist — skipping generation.");
            }
        }
    }
}
