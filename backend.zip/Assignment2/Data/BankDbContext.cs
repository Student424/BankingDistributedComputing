﻿using Bank_Data_Web_Service.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace Bank_Data_Web_Service.Data
{
    public class BankDbContext : DbContext
    {
        public BankDbContext(DbContextOptions<BankDbContext> options) : base(options) { }

        public DbSet<UserProfile> Users => Set<UserProfile>();
        public DbSet<Account> Accounts => Set<Account>();
        public DbSet<Transaction> Transactions => Set<Transaction>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserProfile>()
                .HasIndex(u => u.Email).IsUnique();

            modelBuilder.Entity<Account>()
                .HasIndex(a => a.AccountNumber).IsUnique();

            modelBuilder.Entity<Account>()
                .HasOne(a => a.UserProfile)
                .WithMany(u => u.Accounts)
                .HasForeignKey(a => a.UserProfileId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Transaction>()
                .HasOne(t => t.Account)
                .WithMany(a => a.Transactions)
                .HasForeignKey( t => t.AccountId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
