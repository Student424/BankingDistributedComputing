﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Bank_Data_Web_Service.Models
{
    public class Account
    {
        public int Id { get; set; }

        [Required, MaxLength(24)]
        public string AccountNumber { get; set; } = null!;

        [Range(0, double.MaxValue)]
        [Precision(18,2)]
        public decimal Balance { get; set; }

        [Required, MaxLength(20)]
        public string Type { get; set; } = "Savings";

        //foreign key for userprofile
        public int UserProfileId    { get; set; }
        public UserProfile UserProfile { get; set; } = null!;

        public List<Transaction> Transactions { get; set; } = new();

    }
}
