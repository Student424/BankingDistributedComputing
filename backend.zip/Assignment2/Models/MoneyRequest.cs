﻿namespace Bank_Data_Web_Service.Models
{
    public class MoneyRequest
    {
        public decimal Amount { get; set; }
        public string? Description { get; set; }
    }
}
