﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Bank_Data_Web_Service.Models
{
    public class UserProfile
    {
        public int Id
        {
            get; set;
        }

        [Required, MaxLength(80)]
        public string Name { get; set; } = string.Empty;

        [Required, EmailAddress, MaxLength(120)]
        public string Email { get; set; } = String.Empty;

        [MaxLength(200)]
        public string? Address { get; set; }

        [MaxLength(30)]
        public string?Phone {  get; set; }

        public string? Picture { get; set; }

        [Required]
        public string PasswordHash { get; set; } = null;

        
        public string Role { get; set; } = "User"; 

        [JsonIgnore]
        public List<Account> Accounts { get; set; } = new();

    }
}
