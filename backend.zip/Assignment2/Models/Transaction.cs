﻿using System;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace Bank_Data_Web_Service.Models
{
    public enum TransactionType { Deposit = 1, Withdrawal = 2}
    public class Transaction
    {
        public int Id { get; set; }

        public int AccountId { get; set; }
        public Account? Account { get; set; }

        public DateTime TimestampsUtc { get; set; } = DateTime.UtcNow;

        [Precision(18,2)]
        public decimal Amount { get; set; }

        public TransactionType Type { get; set; }

        //after balance
        [Precision(18,2)]
        public decimal BalanceAfter { get; set; }

        public string? Description { get; set; }
    }
}
