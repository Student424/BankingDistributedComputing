﻿using Bank_Data_Web_Service.Data;
using Bank_Data_Web_Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bank_Data_Web_Service.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly BankDbContext _db;
        public UserController(BankDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserProfile>>> GetAll()
        {
            return Ok(await _db.Users.AsNoTracking().ToListAsync());
        }

        [HttpGet("{id:int}")]
        [HttpGet("~/api/users/{id:int}")]
        public async Task<ActionResult<UserProfile>> GetById(int id)
        {
            var user = await _db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == id);
            if (user == null) return NotFound();
            return Ok(user);
        }

        [HttpPost]
        public async Task<ActionResult<UserProfile>> Create(UserProfile input)
        {
            if(!ModelState.IsValid)
            {
                return ValidationProblem(ModelState);
            }
            _db.Users.Add(input);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = input.Id }, input);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, UserProfile input)
        {
            if (id != input.Id)
                return BadRequest("Id mismatch.");

            if (!await _db.Users.AnyAsync(u => u.Id == id))
                return NotFound();

            _db.Entry(input).State = EntityState.Modified;
            await _db.SaveChangesAsync();

            return Ok(input);
        }


        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var user = await _db.Users.FindAsync(id);
            if (user is null) return NotFound();

            _db.Users.Remove(user);
            await _db.SaveChangesAsync();
            return Ok(new { message = "User deleted successfully" });
        }

        [HttpGet("by-email/{email}")]
        public async Task<ActionResult<UserProfile>> GetByEmail(string email)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == email);
                return user is null ? NotFound() : Ok(user);
        }

    }
}
