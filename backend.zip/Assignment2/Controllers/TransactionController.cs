﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Bank_Data_Web_Service.Data;
using Bank_Data_Web_Service.Models;

namespace Bank_Data_Web_Service.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionsController : ControllerBase
    {
        private readonly BankDbContext _db;
        public TransactionsController(BankDbContext db) => _db = db;

        // GET: /api/transactions/history/1
        [HttpGet("history/{accountId:int}")]
        public async Task<IActionResult> History(int accountId)
        {
            var exists = await _db.Accounts.AnyAsync(a => a.Id == accountId);
            if (!exists) return NotFound();

            var tx = await _db.Transactions
                .Where(t => t.AccountId == accountId)
                .OrderByDescending(t => t.TimestampsUtc)   // column in your DB
                .ToListAsync();

            return Ok(tx);
        }

        // POST: /api/transactions/{accountId}/deposit
        [HttpPost("{accountId:int}/deposit")]
        public async Task<IActionResult> Deposit(int accountId, [FromBody] MoneyRequest body)
        {
            if (body is null || body.Amount <= 0) return BadRequest("Amount must be > 0");

            var acct = await _db.Accounts.FirstOrDefaultAsync(a => a.Id == accountId);
            if (acct is null) return NotFound("Account not found");

            acct.Balance += body.Amount;

            var t = new Transaction
            {
                AccountId = acct.Id,
                TimestampsUtc = DateTime.UtcNow,
                Amount = body.Amount,
                Type = TransactionType.Deposit,  // enum in your model
                BalanceAfter = acct.Balance,
                Description = string.IsNullOrWhiteSpace(body.Description) ? "Deposit" : body.Description
            };

            _db.Transactions.Add(t);
            await _db.SaveChangesAsync();

            return Ok(new { acct.Id, acct.Balance });
        }

        // POST: /api/transactions/{accountId}/withdraw
        [HttpPost("{accountId:int}/withdraw")]
        public async Task<IActionResult> Withdraw(int accountId, [FromBody] MoneyRequest body)
        {
            if (body is null || body.Amount <= 0) return BadRequest("Amount must be > 0");

            var acct = await _db.Accounts.FirstOrDefaultAsync(a => a.Id == accountId);
            if (acct is null) return NotFound("Account not found");
            if (acct.Balance < body.Amount) return BadRequest("Insufficient funds");

            acct.Balance -= body.Amount;

            var t = new Transaction
            {
                AccountId = acct.Id,
                TimestampsUtc = DateTime.UtcNow,
                Amount = body.Amount,
                Type = TransactionType.Withdrawal,
                BalanceAfter = acct.Balance,
                Description = string.IsNullOrWhiteSpace(body.Description) ? "Withdraw" : body.Description
            };

            _db.Transactions.Add(t);
            await _db.SaveChangesAsync();

            return Ok(new { acct.Id, acct.Balance });
        }

        [HttpPost("transfer")]
        public async Task<IActionResult> Transfer([FromBody] TransferRequest req)
        {
            if (req is null || req.Amount <= 0) return BadRequest("Amount must be > 0");
            if (req.FromAccountId == req.ToAccountId) return BadRequest("Accounts must differ");

            var from = await _db.Accounts.FirstOrDefaultAsync(a => a.Id == req.FromAccountId);
            var to = await _db.Accounts.FirstOrDefaultAsync(a => a.Id == req.ToAccountId);
            if (from is null || to is null) return NotFound("Account not found");
            if (from.Balance < req.Amount) return BadRequest("Insufficient funds");

            // simple non-transactional transfer; wrap in a DB transaction if needed
            from.Balance -= req.Amount;
            _db.Transactions.Add(new Transaction
            {
                AccountId = from.Id,
                TimestampsUtc = DateTime.UtcNow,
                Amount = req.Amount,
                Type = TransactionType.Withdrawal,
                BalanceAfter = from.Balance,
                Description = string.IsNullOrWhiteSpace(req.Description) ? "Transfer out" : req.Description
            });

            to.Balance += req.Amount;
            _db.Transactions.Add(new Transaction
            {
                AccountId = to.Id,
                TimestampsUtc = DateTime.UtcNow,
                Amount = req.Amount,
                Type = TransactionType.Deposit,
                BalanceAfter = to.Balance,
                Description = string.IsNullOrWhiteSpace(req.Description) ? "Transfer in" : req.Description
            });

            await _db.SaveChangesAsync();
            return Ok(new
            {
                accountId = to.Id,
                balance = to.Balance
            });

        }

        [HttpGet("all")]
        public async Task<IActionResult> All([FromQuery] DateTime? from, [FromQuery] DateTime? to)
        {
            var q = _db.Transactions.AsQueryable();

            if (from.HasValue) q = q.Where(t => t.TimestampsUtc >= from.Value);
            if (to.HasValue) q = q.Where(t => t.TimestampsUtc <= to.Value);

            var list = await q
                .OrderByDescending(t => t.TimestampsUtc)
                .ToListAsync();

            return Ok(list);
        }

    }
}
