﻿using Bank_Data_Web_Service.Data;
using Bank_Data_Web_Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bank_Data_Web_Service.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountsController : ControllerBase
    {
        private readonly BankDbContext _db;
        public AccountsController(BankDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Account>>> GetAll()
        {
            var list = await _db.Accounts
            .Include(a => a.UserProfile)
            .AsNoTracking()
            .ToListAsync();

            return Ok(list);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Account>> Get(int id)
        {
            var acc = await _db.Accounts.Include(a => a.UserProfile).FirstOrDefaultAsync(a => a.Id == id); ;
            return acc is null ? NotFound() : Ok(acc);
        }

        //Get account by number
        [HttpGet("by-number/{number}")]
        public async Task<ActionResult<Account>> GetByNumber(string number)
        { 
            var acc = await _db.Accounts.Include(a => a.UserProfile).FirstOrDefaultAsync(a => a.AccountNumber == number);
            return acc is null ? NotFound() : Ok(acc);
        }


        [HttpGet("by-user/{userId:int}")]
        public async Task<ActionResult<IEnumerable<Account>>> GetByUser(int userId)
        {
            var list = await _db.Accounts
                .Where(a => a.UserProfileId == userId)
                .AsNoTracking()
                .ToListAsync();
            return Ok(list);
        }

        [HttpPost]
        public async Task<ActionResult<Account>> Create(Account input)
        {
            if (!ModelState.IsValid)
            {
                return ValidationProblem(ModelState);
            }
            if (!await _db.Users.AnyAsync(u => u.Id == input.UserProfileId))
            {
                return BadRequest("UserProfileId not found");
            }
            if(await _db.Accounts.AnyAsync(a => a.AccountNumber == input.AccountNumber))
            {
                return Conflict("AccountNumber already exists.");
            }

            _db.Accounts.Add(input);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = input.Id }, input);

        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, Account input)
        {
            if(id != input.Id)
            {
                return BadRequest("ID mismatch");
            }
            var exists =await _db.Accounts.AnyAsync(a =>a.Id == id);
            if (!exists)
            {
                return NotFound();
            }

            //Prevent direct balance edits ( need to use TransactionController)
            var tracked = await _db.Accounts.AsNoTracking().FirstAsync(a => a.Id == id);
            input.Balance = tracked.Balance;

            _db.Entry(input).State = EntityState.Modified;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var acc = await _db.Accounts.FindAsync(id);
            if (acc is null)
            {
                return NotFound();
            }

            _db.Accounts.Remove(acc);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
